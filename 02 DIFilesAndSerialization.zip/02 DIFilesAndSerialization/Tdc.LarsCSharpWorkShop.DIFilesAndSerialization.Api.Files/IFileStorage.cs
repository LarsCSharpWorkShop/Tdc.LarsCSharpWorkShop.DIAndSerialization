﻿using System.Collections.Generic;
using Tdc.LarsCSharpWorkShop.DIFilesAndSerialization.Api.Common;

namespace Tdc.LarsCSharpWorkShop.DIFilesAndSerialization.Api.Files
{
    public interface IFileStorage
    {
        public List<Customer> Load();
        public void Save(List<Customer> customers);
    }
}
