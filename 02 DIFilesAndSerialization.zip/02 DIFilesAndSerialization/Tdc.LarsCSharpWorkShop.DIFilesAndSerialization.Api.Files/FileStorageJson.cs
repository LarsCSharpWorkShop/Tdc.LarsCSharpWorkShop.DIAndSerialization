﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.DIFilesAndSerialization.Api.Common;
using Tdc.LarsCSharpWorkShop.Api.Serialization;

namespace Tdc.LarsCSharpWorkShop.DIFilesAndSerialization.Api.Files
{
    public class FileStorageJson : IFileStorage
    {
        private readonly IFolderConfig iFolderConfig;
        private string DataDirectory;

        public FileStorageJson(IFolderConfig iFolderConfig)
        {
            this.iFolderConfig = iFolderConfig;
            this.DataDirectory = this.iFolderConfig?.FolderConfigSettings?.FirstOrDefault(x => x.Name == "DataDirectory")?.Path;
        }

        public List<Customer> Load()
        {           
            using (var sr = new StreamReader(Path.Combine(DataDirectory, "customer.json")))
            {
                return SerializationJson.Deserialize<List<Customer>>(sr.ReadToEnd());
            }
        }

        public void Save(List<Customer> customers)
        {            
            using (var sw = new StreamWriter(Path.Combine(DataDirectory, "customer.json")))
            {
                sw.WriteLine(SerializationJson.Serialize(customers));
            }
        }
    }
}
