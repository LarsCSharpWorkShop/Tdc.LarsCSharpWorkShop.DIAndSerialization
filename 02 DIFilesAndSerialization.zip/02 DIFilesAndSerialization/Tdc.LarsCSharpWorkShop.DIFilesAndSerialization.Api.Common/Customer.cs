using System;
using System.Collections.Generic;
using System.Linq;

namespace Tdc.LarsCSharpWorkShop.DIFilesAndSerialization.Api.Common
{
	public partial class Customer 
	{
		public int? CustomerId { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }	
		public List<Invoice> Invoices { get; set; }

		
		public Customer()
		{
		}
		public string GetInvoices(int? productId = null)
		{
			string result = "";
			foreach (var item in Invoices.Where(x => productId == null || x.Products.Any(y => y.ProductId == productId)).ToList())
			{
				result += item.Display() + "\r\n";
				result += "\t----------------------\r\n";
			}
			return result;
		}
        public string Display()
        {
            return $"""
				CustomerId: {CustomerId}

				Name: {FirstName} {LastName}

				Invoices: 
				{GetInvoices()}
				""";
        }

        public string DisplayOnlyInvoiceWithProductId(int productId)
        {
            return $"""
				CustomerId: {CustomerId}

				Name: {FirstName} {LastName}

				Invoices: 
				{GetInvoices(productId)}
				""";
        }        
    }
}


