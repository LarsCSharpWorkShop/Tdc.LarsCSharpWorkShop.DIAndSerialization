using System;

namespace Tdc.LarsCSharpWorkShop.DIFilesAndSerialization.Api.Common
{
	public partial class Product
	{
		public int? ProductId { get; set; }
		public string Name { get; set; }
		public string? Description { get; set; }
		
		public Product()
		{
        }       
        public string Display()
        {
            return $"""
					ProductId: {ProductId}
							Name: {Name}
							Description: {Description}
				""";
        }
    }
}


