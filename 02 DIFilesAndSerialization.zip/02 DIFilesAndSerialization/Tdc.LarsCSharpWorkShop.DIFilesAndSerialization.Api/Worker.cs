﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.DIFilesAndSerialization.Api.Common;
using Tdc.LarsCSharpWorkShop.DIFilesAndSerialization.Api.Files;

namespace Tdc.LarsCSharpWorkShop.ConfigurationsAndDI.Api
{
    public class Worker : BackgroundService
    {
        private readonly IHostApplicationLifetime iHostApplicationLifetime;
        private readonly IFolderConfig iFolderConfig;
        private readonly IFileStorage iFileStorage;
        public Worker(IHostApplicationLifetime iHostApplicationLifetime, IFolderConfig iFolderConfig, IFileStorage iFileStorage)
        {
            this.iFolderConfig = iFolderConfig;
            this.iHostApplicationLifetime = iHostApplicationLifetime;
            this.iFileStorage = iFileStorage;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                List<Customer> customers = iFileStorage.Load(); 
                foreach (var customer in customers)
                {
                    Console.WriteLine(customer.Display());
                }

                // iFileStorage.Save(customers);
            }
            catch
            {
                throw;
            }
            finally
            {
                this.iHostApplicationLifetime.StopApplication();
            }
        }
    }
}
