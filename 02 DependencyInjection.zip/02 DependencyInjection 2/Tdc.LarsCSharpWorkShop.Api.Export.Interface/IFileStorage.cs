﻿using System.Collections.Generic;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;

namespace Tdc.LarsCSharpWorkShop.Api.Export.Interface
{
    public interface IFileStorage
    {   
        public void Export(string customersJson);
    }
}
