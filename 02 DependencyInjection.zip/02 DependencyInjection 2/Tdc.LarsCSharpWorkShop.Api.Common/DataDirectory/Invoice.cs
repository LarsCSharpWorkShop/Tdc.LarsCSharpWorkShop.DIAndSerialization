using System;
using System.Collections.Generic;

namespace Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory
{
	public partial class Invoice
	{
		public int? InvoiceId { get; set; }
		public Customer Customer { get; set; }
		public string Number { get; set; }
		public List<Product> Products { get; set; }

		public Invoice()
		{
        }
        public string GetProducts()
        {
            string result = "";
            foreach (var item in Products)
            {
                result += item.Display() + "\r\n\t";
            }
            return result;
        }
        public string Display()
        {
            return $"""
                        InvoiceId: {InvoiceId}
                            Number: {Number}

                            Products:
                            {GetProducts()}
                """;
        }
    }
}


