using System;

namespace Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory
{
	public partial class InvoiceProduct 
	{
		public int? InvoiceProductId { get; set; }
		public Invoice Invoice { get; set; }
		public Product Product { get; set; }		
		
		public InvoiceProduct()
		{
		}		
	}
}


