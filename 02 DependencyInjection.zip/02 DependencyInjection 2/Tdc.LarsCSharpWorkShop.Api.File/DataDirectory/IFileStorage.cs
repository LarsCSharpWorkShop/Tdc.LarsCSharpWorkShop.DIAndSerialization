﻿using System.Collections.Generic;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;

namespace Tdc.LarsCSharpWorkShop.Api.Files.DataDirectory
{
    public interface IFileStorage
    {       
        public void Export(List<Customer> customers);
    }
}
