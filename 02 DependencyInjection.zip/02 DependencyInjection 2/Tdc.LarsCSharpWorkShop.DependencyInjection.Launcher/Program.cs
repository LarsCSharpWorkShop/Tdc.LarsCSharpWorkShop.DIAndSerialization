﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.DependencyInjection.Api;
using Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory;

IConfiguration configuration = new ConfigurationBuilder()
                        .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                        .AddJsonFile("appsettings.json", false, true)
                        .Build();

IServiceProvider serviceProvider = new ServiceCollection()
   .AddSingleton<IFolderConfig, FolderConfig>(p => FolderConfig.Load(configuration))
   .BuildServiceProvider();

IFolderConfig iFolderConfig = serviceProvider.GetRequiredService<IFolderConfig>();

Worker worker = new(iFolderConfig);
worker.Execute(new FileStorageXml(iFolderConfig));