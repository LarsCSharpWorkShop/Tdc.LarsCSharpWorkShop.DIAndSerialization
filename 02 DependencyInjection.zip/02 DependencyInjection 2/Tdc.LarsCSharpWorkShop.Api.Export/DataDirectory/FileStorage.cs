﻿using System;
using System.Collections.Generic;
using System.Linq;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;

namespace Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory
{
    public class FileStorage 
    {        
        protected readonly IFolderConfig iFolderConfig;
        protected string DataDirectory;
        public FileStorage(IFolderConfig iFolderConfig)
        {
            this.iFolderConfig = iFolderConfig;
            DataDirectory = this.iFolderConfig?.FolderConfigSettings?.FirstOrDefault(x => x.Name == "DataDirectory")?.Path;
        }        
    }
}
