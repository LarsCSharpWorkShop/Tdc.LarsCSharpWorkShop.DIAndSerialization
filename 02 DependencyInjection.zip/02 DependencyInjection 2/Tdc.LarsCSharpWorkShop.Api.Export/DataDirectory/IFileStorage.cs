﻿using System.Collections.Generic;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;

namespace Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory
{
    public interface IFileStorage
    {       
        public void Export(List<Customer> customers);
    }
}
