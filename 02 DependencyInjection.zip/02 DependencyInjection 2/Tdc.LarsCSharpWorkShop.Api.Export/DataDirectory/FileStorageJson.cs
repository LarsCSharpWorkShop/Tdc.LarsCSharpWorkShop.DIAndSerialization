﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.Api.Serialization;
using Tdc.LarsCSharpWorkShop.Api.Export.Interface;

namespace Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory
{
    public class FileStorageJson : FileStorage, IFileStorage
    {
        public FileStorageJson(IFolderConfig iFolderConfig) : base(iFolderConfig)
        {
        }
        public void Export(string customersJson)
        {
            List<Customer> customers = Serialization.SerializationJson.Deserialize<List<Customer>>(customersJson);
            using (var sw = new StreamWriter(Path.Combine(DataDirectory, "customer.json")))
            {
                sw.WriteLine(SerializationJson.Serialize(customers));
            }
        }
    }
}