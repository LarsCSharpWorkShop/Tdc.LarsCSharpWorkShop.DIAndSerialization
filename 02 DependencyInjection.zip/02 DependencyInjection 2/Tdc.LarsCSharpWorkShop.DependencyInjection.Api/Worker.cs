﻿using System;
using System.Collections.Generic;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Export.Interface;
using Tdc.LarsCSharpWorkShop.Api.Serialization;

namespace Tdc.LarsCSharpWorkShop.DependencyInjection.Api
{
    public class Worker
    {
        private List<Customer> Customers = null;        

        public Worker(IFolderConfig iFolderConfig)
        {
            FileStorageCsv fileStorageCsv = new(iFolderConfig);
            Customers = fileStorageCsv.Load();
        }
        public void Execute(IFileStorage fileStorage)
        {                        
            fileStorage.Export(SerializationJson.Serialize(Customers));
            Console.WriteLine("Exported");
        }   
    }
}
