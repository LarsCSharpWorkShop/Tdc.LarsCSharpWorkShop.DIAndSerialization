﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;

namespace Tdc.LarsCSharpWorkShop.DependencyInjection.Api
{
    public class FileStorageCsv
    {
        private readonly IFolderConfig iFolderConfig;
        private string DataDirectory;

        public FileStorageCsv(IFolderConfig iFolderConfig)
        {
            this.iFolderConfig = iFolderConfig;
            DataDirectory = this.iFolderConfig?.FolderConfigSettings?.FirstOrDefault(x => x.Name == "DataDirectory")?.Path;
        }

        public List<Customer> Load()
        {
            List<Customer> customers = new();
            List<Product> Products = new();
            List<Invoice> Invoices = new();
            List<InvoiceProduct> InvoiceProducts = new();

            using (var sr = new StreamReader(Path.Combine(DataDirectory, "Product.dat")))
            {
                List<string> productLines = sr.ReadToEnd().Split("\r\n").ToList();
                foreach (var productLine in productLines.Where(x => !string.IsNullOrWhiteSpace(x)))
                {
                    List<string> parts = productLine.Split(',').ToList();
                    var product = new Product()
                    {
                        ProductId = Convert.ToInt32(parts[0]),
                        Name = parts[1],
                        Description = parts[2]
                    };
                    Products.Add(product);
                }
            }
            using (var sr = new StreamReader(Path.Combine(DataDirectory, "Customer.dat")))
            {
                List<string> customerLines = sr.ReadToEnd().Split("\r\n").ToList();
                foreach (var customerLine in customerLines.Where(x => !string.IsNullOrWhiteSpace(x)))
                {
                    List<string> parts = customerLine.Split(',').ToList();

                    var customer = new Customer()
                    {
                        CustomerId = Convert.ToInt32(parts[0]),
                        FirstName = parts[1],
                        LastName = parts[2]
                    };
                    customer.Invoices = new List<Invoice>();
                    customers.Add(customer);
                }
            }
            using (var sr = new StreamReader(Path.Combine(DataDirectory, "Invoice.dat")))
            {
                List<string> invoiceLines = sr.ReadToEnd().Split("\r\n").ToList();
                foreach (var invoiceLine in invoiceLines.Where(x => !string.IsNullOrWhiteSpace(x)))
                {
                    List<string> parts = invoiceLine.Split(',').ToList();

                    var invoice = new Invoice()
                    {
                        InvoiceId = Convert.ToInt32(parts[0]),
                        Number = parts[2]
                    };
                    invoice.Customer = customers.FirstOrDefault(x => x.CustomerId == Convert.ToInt32(parts[1]));
                    invoice.Products = null;

                    Invoices.Add(invoice);
                }
            }
            using (var sr = new StreamReader(Path.Combine(DataDirectory, "InvoiceProduct.dat")))
            {
                List<string> invoiceProductLines = sr.ReadToEnd().Split("\r\n").ToList();
                foreach (var invoiceProductLine in invoiceProductLines.Where(x => !string.IsNullOrWhiteSpace(x)))
                {
                    List<string> parts = invoiceProductLine.Split(',').ToList();

                    var invoiceProduct = new InvoiceProduct()
                    {
                        InvoiceProductId = Convert.ToInt32(parts[0]),
                    };
                    invoiceProduct.Invoice = Invoices.FirstOrDefault(x => x.InvoiceId == Convert.ToInt32(parts[1]));
                    invoiceProduct.Product = Products.FirstOrDefault(x => x.ProductId == Convert.ToInt32(parts[2]));

                    InvoiceProducts.Add(invoiceProduct);
                }
            }
            foreach (var invoice in Invoices)
            {
                invoice.Products = InvoiceProducts.Where(x => x.Invoice.InvoiceId == invoice.InvoiceId).Select(s => s.Product).ToList();
                var customer = customers.FirstOrDefault(x => x.CustomerId == invoice.Customer.CustomerId);
                invoice.Customer = null;
                customer.Invoices.Add(invoice);
            }

            return customers;
        }
        public void Export(List<Customer> customers)
        {
            using (var sw = new StreamWriter(Path.Combine(DataDirectory, "Customer.csv")))
            {
                foreach (var customer in customers)
                {
                    sw.Write($"{customer.CustomerId},{customer.FirstName},{customer.LastName}");
                    foreach (var invoice in customer.Invoices)
                    {
                        sw.Write($",{invoice.InvoiceId},{customer.CustomerId},{invoice.Number}");
                        foreach (var product in invoice.Products)
                        {
                            sw.Write($",{product.ProductId},{product.Name},{product.Description}");
                        }
                    }
                    sw.WriteLine();
                }
            }
        }
    }
}