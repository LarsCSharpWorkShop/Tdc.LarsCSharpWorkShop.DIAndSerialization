﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;

namespace Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory
{
    public abstract class FileStorage
    {
        protected readonly IFolderConfig iFolderConfig;
        protected string DataDirectory;
        public abstract void Export(List<Customer> customers);

        public FileStorage(IFolderConfig iFolderConfig)
        {
            this.iFolderConfig = iFolderConfig;
            DataDirectory = this.iFolderConfig?.FolderConfigSettings?.FirstOrDefault(x => x.Name == "DataDirectory")?.Path;
        }
    }
}
