﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.Api.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory
{
    public class FileStorageJson : FileStorage
    {
        public FileStorageJson(IFolderConfig iFolderConfig) : base(iFolderConfig)
        {
        }
        public override void Export(List<Customer> customers)
        {            
            using (var sw = new StreamWriter(Path.Combine(DataDirectory, "customer.json")))
            {
                sw.WriteLine(SerializationJson.Serialize(customers));
            }
        }
    }
}