﻿using System.Collections.Generic;
using System.IO;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.Api.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory
{
    public class FileStorageXml : FileStorage
    {
        public FileStorageXml(IFolderConfig iFolderConfig) : base (iFolderConfig)
        {            
        }        
        public override void Export(List<Customer> customers)
        {
            using (var sw = new StreamWriter(Path.Combine(DataDirectory, "customer.xml")))
            {
                sw.WriteLine(customers.Serialize());
            }
        }
    }
}