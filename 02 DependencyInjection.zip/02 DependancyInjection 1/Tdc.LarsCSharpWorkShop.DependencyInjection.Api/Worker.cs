﻿using System;
using System.Collections.Generic;
using Tdc.LarsCSharpWorkShop.Api.Common.DataDirectory;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.Api.Export.DataDirectory;

namespace Tdc.LarsCSharpWorkShop.DependencyInjection.Api
{
    public class Worker
    {
        private List<Customer> Customers = null;

        public Worker(IFolderConfig iFolderConfig)
        {            
            FileStorageCsv fileStorageCsv = new(iFolderConfig);
            Customers = fileStorageCsv.Load();
        }
        public void Execute(FileStorage fileStorage)
        {
            fileStorage.Export(Customers);           
            Console.WriteLine("Exported");
        }  
    }
}
